function setup(){
	var xSize = 500;
	var ySize = 500;
	createCanvas(xSize, ySize, WEBGL);
}

function draw(){
	box(10,10,10);
	//translate(0,0,10);
}
